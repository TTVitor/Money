import axios from 'axios';
import inquirer from 'inquirer';

async function convertCurrency() {
  const { from, to, amount } = await inquirer.prompt([
    { name: 'from', message: 'Moeda de origem (ex: USD):' },
    { name: 'to', message: 'Moeda destino (ex: BRL):' },
    {
      name: 'amount',
      message: 'Valor:',
      validate: val => !isNaN(val) && Number(val) > 0 || 'Digite um valor numérico positivo',
    }
  ]);

  try {
    const response = await axios.get(`https://api.frankfurter.app/latest?amount=${amount}&from=${from}&to=${to}`);
    const rate = response.data.rates[to.toUpperCase()];

    if (!rate) {
      console.error('Moeda destino inválida ou não suportada.');
      return;
    }

    console.log(`${amount} ${from.toUpperCase()} = ${rate.toFixed(2)} ${to.toUpperCase()}`);
  } catch (error) {
    console.error('Erro ao buscar taxa de câmbio:', error.message);
  }
}

convertCurrency();
